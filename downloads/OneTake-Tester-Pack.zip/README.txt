OneTake narrated tester pack

English: Microsoft William, Australian male, measured pace.
Chinese tutorial and 27-second ad: Microsoft Yunxi, Mandarin male.
All MP4s contain embedded AAC stereo narration.

Complete one Free scan with Last year, then Lite, Max trial, Max, Restore.
Purchase footage is local StoreKit, not a TestFlight recording.
Chinese tutorial uses Chinese narration and captions over the English UI.
All captured photos are synthetic test fixtures.

Voice catalog: https://learn.microsoft.com/en-us/azure/ai-services/speech-service/language-support?tabs=tts
